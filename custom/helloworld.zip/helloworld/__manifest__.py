{
    'name': 'Sale Transaction Number Extension',
    'version': '1.0',
    'category': 'Sales',
    'summary': 'Adds a transaction number field to Sales Orders',
    'depends': ['sale'],
    'data': [
    'security/ir.model.access.csv',
    'views/sale_order_view.xml',
],
    'installable': True,
    'application': False,
}
